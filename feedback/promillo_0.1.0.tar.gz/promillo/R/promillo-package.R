
#' promillo
#'
#' Lösung für FoRt: Paket für die 
#' Promillerechner-Aufgaben. Siehe \code{\link{tell_me_how_drunk}}.
#'
#' @name promillo
#' @docType package
#' @encoding UTF-8
# hier @encoding angeben wg. Umlauten, nicht nötig für englischsprachige Doku.
NULL