#' Berechnet Blutalkohol am Ende der Party
#'
#' Berechnet ungefähre Blutalkoholkonzentration (BAK) zum Ende der Trinkphase
#' `drinking_time[2]` mit der Methode von
#' [promille-rechner.org](https://web.archive.org/web/20150123143123/http://promille-rechner.org/erlaeuterung-der-promille-berechnung/)
#' (Stand: 2014/10/8).
#'
#' Die verwendete Methode kombiniert die BAK-Formeln von Widmark und Watson. Sie
#' kann allerdings wichtige Faktoren wie gesundheitliche Verfassung, Gewohnheit
#' oder die Einnahme von Medikamenten die die tatsächliche BAK stark
#' beeinflussen nicht berücksichtigen. Angenommen wird ausserdem ein Abbau der
#' Konzentration von 0.15 Promille pro Stunde nach Ablauf der ersten vollen
#' Stunde.
#'
#' @references [Wikipedia-Artikel zu BAK](http://de.wikipedia.org/wiki/Blutalkoholkonzentration#Berechnung_der_BAK)
#'
#' @param age Alter in Jahren
#' @param sex Geschlecht
#' @param height Körpergrösse in cm
#' @param weight Körpergewicht in kg.
#' @param drinking_time Vektor aus 2  Zeitpunkten (Anfang, Ende) in POSIXct
#'   oder POSIXlt-Format
#' @param drinks Benamte Liste oder benamter Vektor mit möglichen Namen
#'   `"massn", "hoibe", "wein", "schnaps"`  die/der die Anzahl der
#'   konsumierten Getränke enthält.
#' @return Geschätzte BAK zum Zeitpunkt `drinking_time[2]`
#' @seealso [get_alcohol()]
#' @examples
#' tell_me_how_drunk(age = 34, sex = "M", height = 190, weight = 87,
#'   drinking_time =
#'     as.POSIXct(c("2014-10-03 18:15:00",  "2014-10-03 22:55:00")),
#'   drinks = c("massn" = 2, "schnaps" = 4))
#' @encoding UTF-8
#' @export
#' @md
# @encoding angeben da wir hier Umlaute etc benutzen die nicht ASCII sind.
# Nicht nötig für Doku auf englisch, normalerweise.
tell_me_how_drunk <- function(age, sex = c("Male", "Female"), height, weight,
  drinking_time, drinks) {
  if (age < 16 | age > 90) {
    warning("... und das in Deinem Alter!")
  }
  alcohol_drunk <- get_alcohol(drinks)
  bodywater <- get_bodywater(sex, age, height, weight)
  get_permille(alcohol_drunk, bodywater, drinking_time)
}

# utilities --------------------------------------------------------------------

# Erstellen einer (zunächst leeren) Hilfe-Seite "promillerechner-utilities" die
# nur aus einem Titel besteht mittels Dokumentation eines NULL-Objekts. Dies
# erzeugt gewissermaßen einen "Container" in dem wir die Hilfeseiten für die
# Utility-Funktionen dann mittels
# #' @rdname promillerechner-utilities
# zusammenführen. Wichtig hier zu beachten dass wir im Folgenden dann explizite
# @name bzw @description tags brauchen auf die wir sonst verzichten können --
# roxygen interpretiert den ersten Absatz ohne @-tag als @name, den zweiten
# ohne @-tag als @description und den dritten und fortfolgende ohne @-tag als
# @details. Wenn wir uns wie hier nicht an diese Reihenfolge halten, müssen wir
# aber eben explizit angeben was was ist...

#' @name promillerechner-utilities
#' @title Utilities zur BAK-Berechnung
#' @encoding UTF-8
#' @import checkmate
#' @md
NULL



#' @description `get_alcohol` berechnet die aufgenommene Menge Alkohol in
#'   g.
#'
#' @details Angenommen werden hier je 6\% für `massn` (also: 1l) und
#'   `hoibe` (also: 0.5l), 0.2l und 11\% für `wein` und 4cl und 40\%
#'   für `schnaps`.
#'
#' @inheritParams tell_me_how_drunk
#' @rdname promillerechner-utilities
#' @seealso [tell_me_how_drunk()]
#' @md
get_alcohol <- function(drinks) {
  # inputs homogen machen:
  drinks <- unlist(drinks)
  # inputs checken: #library(checkmate) (über @imports gelöst, s.o.)
  assert_subset(names(drinks), choices = c("massn", "hoibe", "wein", "schnaps"),
    empty.ok = FALSE)
  assert_numeric(drinks, lower = 0)
  # equivalent (roughly):
  ## stopifnot(!is.null(names(drinks)),
  ##  all(names(drinks) %in% c("massn", "hoibe", "wein", "schnaps")),
  ##  is.numeric(drinks),
  ##  all(drinks >= 0))


  # in ml bzw (volumen)prozent
  volume <- c(
    "massn"    = 1000,
    "hoibe"   = 500,
    "wein"    = 200,
    "schnaps" = 40)
  alcohol_concentration <- c(
    "massn"    = 0.06,
    "hoibe"   = 0.06,
    "wein"    = 0.11,
    "schnaps" = 0.4)
  alcohol_density <- 0.8

  # die indizierung mit names(drinks) erzeugt vektoren von volumen
  # und alkoholgehalt die zu den einträgen in drinks passen
  # (richtige reihenfolge & länge):
  sum(drinks * volume[names(drinks)] *
      alcohol_concentration[names(drinks)] * alcohol_density)
}




#' @description `get_bodywater` berechnet die Gesamtkörperwassermenge.
#'
#' @details Für die Gesamtkörperwassermenge wird die Formel von Whatson mit
#'   einer Modifikation von Eickner die die Altersabhängigkeit bei Frauen
#'   berücksichtigt verwendet.
#'
#' @inheritParams tell_me_how_drunk
#' @rdname promillerechner-utilities
#' @md
get_bodywater <- function(sex = c("Male", "Female"), age, height, weight) {
  sex <- match.arg(sex)
  #stopifnot(is.numeric(age), is.numeric(height), is.numeric(weight),
  #  age >= 10, height >= 100, weight >= 40,
  #  age <= 110, height <= 230, weight <= 300)
  #library(checkmate) (über @imports gelöst, s.o.)
  assert_numeric(age, lower = 10, upper = 110)
  assert_numeric(height, lower = 100, upper = 230)
  assert_numeric(weight, lower = 40, upper = 300)

  coef <- if (sex == "Male") {
    c(2.447, -0.09516, 0.1074, 0.3362)
  } else {
    c(0.203, -0.07, 0.1069, 0.2466)
  }
  t(coef) %*% c(1, age, height, weight)
}

#' @description  `get_permille` berechnet die BAK am Ende von
#'   `drinking_time`.
#'
#' @inheritParams tell_me_how_drunk
#' @param alcohol_drunk Ergebnis aus [get_alcohol()]
#' @param bodywater Ergebnis aus [get_bodywater()]
#' @rdname promillerechner-utilities
#' @md
get_permille <- function(alcohol_drunk, bodywater, drinking_time) {
  #library(checkmate) (über @imports gelöst, s.o.)
  assert_class(drinking_time, "POSIXt")
  stopifnot(drinking_time[1] < drinking_time[2])

  alcohol_density <- 0.8
  blood_density <- 1.055
  permille <- alcohol_density * alcohol_drunk / (blood_density * bodywater)

  partylength <- difftime(drinking_time[2], drinking_time[1], units = "hours")
  sober_per_hour <- 0.15
  max(0, permille  - (max(0, partylength - 1) * sober_per_hour))
}
