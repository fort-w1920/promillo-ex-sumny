library(testthat)
library(promillo)

test_check("promillo")
